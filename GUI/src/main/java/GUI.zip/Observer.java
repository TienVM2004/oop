public abstract class Observer {
    public abstract void notification();

}
