public class MoveOrNot {
    public static boolean Move = false;
}
